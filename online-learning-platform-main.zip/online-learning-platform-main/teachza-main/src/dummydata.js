export const coursesCard = [
  {
    id: 1,
    cover: "../images/courses/c1.jpg",
    coursesName: "Introducing to Software Engineering"
  },
  {
    id: 2,
    cover: "../images/courses/c2.jpg",
    coursesName: "Enhancing Adobe Photoshop CC 2020 Skills"
  },
  {
    id: 3,
    cover: "../images/courses/c3.avif",
    coursesName: "HTML, CSS, and Javascript for Web Developers"
  },
  {
    id: 4,
    cover: "../images/courses/c4.avif",
    coursesName: "Introducing to Programming with WordPress"
  },
  {
    id: 5,
    cover: "../images/courses/c5.svg",
    coursesName: "Introducing to Programming with ReactJS"
  },
  {
    id: 6,
    cover: "../images/courses/c6.jpg",
    coursesName: "Introducing to with JAVA"
  }
]
