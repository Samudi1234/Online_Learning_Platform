package com.example.onlinecourse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineCourseApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineCourseApplication.class, args);
	}

}
