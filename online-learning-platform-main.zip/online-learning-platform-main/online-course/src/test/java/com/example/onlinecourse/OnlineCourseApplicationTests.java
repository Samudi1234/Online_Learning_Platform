package com.example.onlinecourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineCourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
